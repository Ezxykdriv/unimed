package principal;

import com.zehon.FileTransferStatus;
import exception.ExceptionGeral;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import util.SSHConect;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import model.Diretorio;
import util.BDConector;
import util.Properties;

/**
 *
 * @author DTI - Unimed MS
 */
public class VerificarArquivos {

    private static SSHConect ssh;
    private static String host = "";
    private static String username = "";
    private static String password = "";
    private static String sftpDiretorioEnvio = "";
    private static String sftpDiretorioRecebimento = "";

    private static Connection conn;

    private static void copiarArquivos() {
        try {
            conn = BDConector.getConection();
            if (conn == null) {
                ExceptionGeral.gravaException("Não foi possível conectar ao banco de dados", Level.SEVERE, null);
                System.exit(0);
            }
            Properties properties = new Properties();

            ssh = new SSHConect(properties);

            DateFormat dateFormat = new SimpleDateFormat("yyyy");
            String anoAtual = dateFormat.format(new Date());

            String pathLocal = properties.getDiretorioDestino() + anoAtual 
                                + properties.getSubPastaDiretorioDestino();

            criaDiretorio(properties.getDiretorioDestino(), anoAtual);

            for (Diretorio diretorio : Diretorio.values()) {
                for (Iterator<String> it = ssh.getNomeDosArquivosNoDiretorio(diretorio.getDescricao()).iterator(); it.hasNext();) {
                    String nomeArquivo = it.next();
                    if (FileTransferStatus.SUCCESS == ssh.copiaArquivo(nomeArquivo, pathLocal, diretorio.getDescricao())) {
                        String nomeArquivoDescompactado = descompactaArquivo(pathLocal, nomeArquivo);
                        if (nomeArquivoDescompactado != null) {
                            if (BDConector.insertUngPtu(nomeArquivoDescompactado)) {
                                ssh.removeArquivoRemoto(nomeArquivo, diretorio.getDescricao());
                            }
                        }
                    }
                }
            }
            ssh.getCloseCache();
        } catch (SQLException e) {
            ExceptionGeral.gravaException("Erro no método copiarArquivos da classe principal", Level.SEVERE, e);
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(VerificarArquivos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void main(String[] args) {
        Locale.setDefault(new Locale("pt", "BR"));

        copiarArquivos();

    }

    private static void criaDiretorio(String dirDestino, String ano) {
        try {
            File file = new File(dirDestino + ano);
            if (!file.exists()) {
                File pasta = new File(dirDestino + ano);
                if (!pasta.exists()) {
                    pasta.mkdirs();
                }
                //cria a pasta PTU
                pasta = new File(dirDestino + ano + "/PTUA500/");
                if (!pasta.exists()) {
                    pasta.mkdirs();
                }
                //Cria pasta Anexo
                pasta = new File(dirDestino + ano + "/PTUA500/Anexos/");
                if (!pasta.exists()) {
                    pasta.mkdirs();
                }
            }
        } catch (Exception e) {
            ExceptionGeral.gravaException("Erro ao gerar os diretórios", Level.INFO, e);
        }
    }

    private static String descompactaArquivo(String localDirPath, String arquivo) {
        int BUFFER = 4096;
        InputStream is = null;
        BufferedOutputStream dest = null;
        ZipFile zipfile = null;
        ZipEntry FileinCompac = null;
        try {
            File diretorio = new File(localDirPath);//pasta temporaria dos arquivos
            File arquivoDelete = new File(diretorio + File.separator + arquivo);
            boolean extensao = arquivo.contains(".zip");
            if (extensao == true) {
                zipfile = new ZipFile(diretorio + File.separator + arquivo); //pasta onde os arquivos estão srv
                Enumeration e = zipfile.entries();
                while (e.hasMoreElements()) {
                    FileinCompac = (ZipEntry) e.nextElement();
                    is = new BufferedInputStream(zipfile.getInputStream(FileinCompac));
                    int count;
                    byte bits[] = new byte[BUFFER];
                    String DirFileDescompac = diretorio + File.separator + FileinCompac.getName().toUpperCase();
                    FileOutputStream fos = new FileOutputStream(DirFileDescompac);
                    dest = new BufferedOutputStream(fos);
                    while ((count = is.read(bits, 0, BUFFER)) > 0) {
                        dest.write(bits, 0, count);
                    }
                    dest.flush();
                }

                arquivoDelete.delete();
                if (FileinCompac != null) {
                    return FileinCompac.getName().toUpperCase();
                }
            }
        } catch (IOException ex) {
            ExceptionGeral.gravaException("Não foi possível descompactar o arquivo " + arquivo, Level.SEVERE, ex);
            return null;
        } finally {
            try {
                if (dest != null) {
                    dest.flush();
                    dest.close();
                }

                if (is != null) {
                    is.close();
                }

                if (zipfile != null) {
                    zipfile.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(VerificarArquivos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }

}
