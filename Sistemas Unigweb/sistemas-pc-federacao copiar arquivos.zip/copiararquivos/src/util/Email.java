package util;

import exception.ExceptionGeral;
import java.util.logging.Level;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

/**
 *
 * @author DTI - Unimed MS
 */
public class Email {

    public static void email(String assunto, String Mensagem) {
        Properties p = new Properties();
        SimpleEmail email = new SimpleEmail();
        try {
            email.setDebug(false);
            email.setHostName(p.getSmtp());
            email.addTo(p.getEmailDestino()); 
            email.setFrom(p.getEmailOrigem()); 
            email.setSubject(assunto); 
            email.setMsg(Mensagem); 
            email.setAuthentication(p.getEmailOrigem(), p.getSenhaEmail());
            email.setSmtpPort(587);
            email.setSSL(false);
            email.setTLS(false);
            email.send();
        } catch (EmailException e) {
            ExceptionGeral.gravaException("Não foi possível enviar e-mail", Level.SEVERE, e);
        }
    }
}
