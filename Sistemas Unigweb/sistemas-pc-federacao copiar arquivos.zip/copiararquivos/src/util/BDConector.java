package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import exception.ExceptionGeral;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Locale;
import java.util.logging.Level;

/**
 *
 * @author DTI - Unimed MS
 */
public class BDConector {

    public static Connection getConection() {
        Locale.setDefault(new Locale("pt", "BR"));
        Connection conn = null;
        Properties properties = new Properties();
        try {
            Class.forName(properties.getDriver());
            String url = properties.getAlias();
            conn = DriverManager.getConnection(url, properties.getUserBD(), properties.getPasswordBD());
        } catch (ClassNotFoundException | SQLException e) {
            return null;
        }
        return conn;
    }

    //Método inseri uma linha na tabela UNG_PTU, informando que o arquivo pode ser importado!
    public static boolean insertUngPtu(String arquivo) throws SQLException {
        Locale.setDefault(new Locale("pt", "BR"));
        try {
            Connection conn = getConection();
            PreparedStatement ps = conn.prepareStatement("insert INTO ung_ptu (ptu_id, ptu_data, ptu_time, ptu_file, ptu_status, ptu_op) "
                    + "VALUES (S_UNG_PTU.nextval, sysdate, systimestamp, ?,'N','in')");
            ps.setString(1, arquivo);
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (SQLException e) {
            ExceptionGeral.gravaException("Não foi possível inserir o arquivo " + arquivo + " na tabela ung_ptu", Level.SEVERE, e);
            return false;
        }        
    }

    //Fábio - 20/02/2015
    /*Método provisório para importação de arquivos. Devido ao problema de não 
    ter permissão para excluir arquivos no diretório da Unimed Brasil*/
    public boolean getVerificaJaImportou(String arquivo) {
        Locale.setDefault(new Locale("pt", "BR"));
        Boolean resultado = false;
        try {
            Connection conn = getConection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT count(*) as qtd FROM UNG_PTU P "
                    + "WHERE P.PTU_FILE = '" + arquivo + "' AND P.PTU_DATA BETWEEN TO_DATE('19/02/2015') AND SYSDATE");
            if (rs.next()) {
                int qtd = rs.getInt("qtd");
                if (qtd == 0) {
                    resultado = true;
                } else {
                    resultado = false;
                }
            }
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            ExceptionGeral.gravaException("Não possível verificar se o arquivo " + arquivo + " já foi importado. \n", Level.SEVERE, e);
            return resultado;
        }
        return resultado;
    }
    /**
     * ************************************************************************
     */
}
