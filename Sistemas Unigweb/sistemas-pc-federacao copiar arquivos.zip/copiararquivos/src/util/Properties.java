package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import exception.ExceptionGeral;
import java.util.logging.Level;
/**
 *
 * @author DTI - Unimed MS
 */
public class Properties{

    private String smtp;
    private String emailOrigem;
    private String emailDestino;
    private String senhaEmail;
    private String host;
    private String user;
    private String password;
    private String diretorioEnvio;
    private String diretorioRecebimento;
    private String diretorioDestino;
    private String subPastaDiretorioDestino;
    private String driver;
    private String alias;
    private String userBD;
    private String passwordBD;   
    private final String dirArqConfig = "configuracao/Configuracao.properties";
    private Integer port;
    
    java.util.Properties proper = RetProperties();

    public java.util.Properties RetProperties(){
        File file = new File(dirArqConfig);
        java.util.Properties props = new java.util.Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            props.load(fis);
            fis.close();
        } catch (IOException e) {
            ExceptionGeral.gravaException("Erro ao ler arquivo properties \n", Level.SEVERE, e);
        }
        return props;
    }
    public String getSmtp(){
        smtp = proper.getProperty("SMTP");
        return smtp;
    }
    public String getEmailOrigem(){
        emailOrigem = proper.getProperty("EMailOrigem");
        return emailOrigem;
    }
    public String getEmailDestino(){
        emailDestino = proper.getProperty("EMailDestino");
        return emailDestino;
    }
    public String getSenhaEmail(){
        senhaEmail = proper.getProperty("SenhaEMail");
        return senhaEmail;
    }
    public String getHost(){
        host = proper.getProperty("Host");
        return host;
    }
    public String getUser(){
        user = proper.getProperty("User");
        return user;
    }
    public String getPassword(){
        password = proper.getProperty("Password");
        return password;
    }
    public Integer getPort(){
        port = Integer.parseInt(proper.getProperty("Port"));
        return port;
    }
    public String getDiretorioEnvio(){
        diretorioEnvio = proper.getProperty("DiretorioEnvio");
        return diretorioEnvio;
    }
    public String getDiretorioRecebimento(){
        diretorioRecebimento = proper.getProperty("DiretorioRecebimento");
        return diretorioRecebimento;
    }
    public String getDiretorioDestino(){
        diretorioDestino = proper.getProperty("DiretorioDestino");
        return diretorioDestino;
    }
    public String getSubPastaDiretorioDestino(){
        subPastaDiretorioDestino = proper.getProperty("SubPastaDiretorioDestino");
        return subPastaDiretorioDestino;
    }
    public String getDriver(){
        driver = proper.getProperty("Driver");
        return driver;
    }
    public String getAlias(){
        alias = proper.getProperty("Alias");
        return alias;
    }
    public String getUserBD(){
        userBD = proper.getProperty("UserBD");
        return userBD;
    }
    public String getPasswordBD(){
        passwordBD = proper.getProperty("PasswordBD");
        return passwordBD;
    }
}
