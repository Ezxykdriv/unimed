package util;

import com.zehon.exception.FileTransferException;
import com.zehon.sftp.SFTPClient;
import exception.ExceptionGeral;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author DTI - Unimed MS
 */
public class SSHConect {
    
    private String host;
    private String user;
    private String password;
    private String diretorioEnvio;
    private String diretorioRecebimento;
    private Integer port;

    private SFTPClient ssh;

    public SSHConect(Properties pc) {
        this.host = pc.getHost();
        this.user = pc.getUser();
        this.password = pc.getPassword();
        this.port = pc.getPort();
        this.diretorioEnvio = pc.getDiretorioEnvio();
        this.diretorioRecebimento = pc.getDiretorioRecebimento();
        ssh = new SFTPClient(host, port, user, password);
    }
    
    /**
     * Método que retorna a conexão com a Unimed Brasil SFTP;
     *
     * @return SShConect, do tipo SFTPClient;
     */
    public SFTPClient getSShConect() {
        return ssh;
    }

    public String getDiretorioEnvio() {
        return diretorioEnvio;
    }

    public String getDiretorioRecebimento() {
        return diretorioRecebimento;
    }

    //Método que retorna o nome dos arquivos 
    public List<String> getNomeDosArquivosNoDiretorio(String diretorio) {
        List<String> lista = new ArrayList<>();
        String[] arquivosPTU;
        if (this.ssh == null) {
            throw new IllegalStateException();
        }
        try {
            if (diretorio.equalsIgnoreCase("Envio")) {
                arquivosPTU = ssh.getFileNamesInFolder(diretorioEnvio);
                for (String nomeArquivo : arquivosPTU) {
                    if (getDataModificacaoArquivo(diretorioEnvio + File.separator + nomeArquivo)) {
                        lista.add(nomeArquivo);
                    }
                }
            } else {
                arquivosPTU = ssh.getFileNamesInFolder(diretorioRecebimento);
                for (String nomeArquivo : arquivosPTU) {
                    if (getDataModificacaoArquivo(diretorioRecebimento + "/" + nomeArquivo)) {
                        lista.add(nomeArquivo);
                    }
                }
            }
        } catch (FileTransferException e) {
            ExceptionGeral.gravaException("Não foi possível verificar o nome dos arquivos no diretório " + diretorio, Level.SEVERE, e);
        }
        return lista;
    }

    public boolean getDataModificacaoArquivo(String arquivoComDiretorio) {
        try {
            //Pega a data de modificação do arquivo
            Long dataModificacao = ssh.getLastModificationTime(arquivoComDiretorio);

            //Pega a hora em que o arquivo foi modificado
            Calendar calendarModificacao = Calendar.getInstance();
            calendarModificacao.setTimeInMillis(dataModificacao);

            //Pega a hora atual
            Date dataAtual = new Date();
            Long longDataAtual = dataAtual.getTime();
            Calendar calendarAtual = Calendar.getInstance();
            calendarAtual.setTimeInMillis(longDataAtual);

            if (calendarModificacao.get(Calendar.MONTH) < calendarAtual.get(Calendar.MONTH)) {
                return true;
            } else if (calendarModificacao.get(Calendar.DAY_OF_MONTH) < calendarAtual.get(Calendar.DAY_OF_MONTH)) {
                return true;
            } else if (calendarModificacao.get(Calendar.DAY_OF_MONTH) == calendarAtual.get(Calendar.DAY_OF_MONTH)) {
                if (calendarModificacao.get(Calendar.HOUR_OF_DAY) < calendarAtual.get(Calendar.HOUR_OF_DAY)) {
                    return true;
                }
            }
        } catch (FileTransferException e) {
            ExceptionGeral.gravaException("Não foi possível ver a data de modificação do arquivo "
                    + arquivoComDiretorio , Level.SEVERE, e);
        }
        return false;
    }

    //Método que copia os arquivos do diretório remoto para um diretório local
    public Integer copiaArquivo(String arquivo, String diretorioLocal, String diretorio) {
        if (this.ssh == null) {
            throw new IllegalStateException();
        }
        try {
            Pattern re_filt = Pattern.compile("^\\d{8}_\\d{8}_[a-z][a-z_0-9]{7}_\\d{3}\\.(zip)$", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            Matcher match = re_filt.matcher(arquivo);
            Boolean ArquivoValidado = match.find();
            if (ArquivoValidado) {
                if (diretorio.equalsIgnoreCase("Envio")) {
                    return ssh.getFile(arquivo, diretorioEnvio, diretorioLocal);
                    //statusArquivosPTU = SFTP.getFile(arquivo, DiretorioEnvio, Host, User, Password, diretorioLocal);
                } else {
                    return ssh.getFile(arquivo, diretorioRecebimento, diretorioLocal);
                    //statusArquivosPTU = SFTP.getFile(arquivo, DiretorioRecebimento, Host, User, Password, diretorioLocal);
                }
            }else{
                removeArquivoRemoto(arquivo, diretorio);
            }
        } catch (FileTransferException e) {
            ExceptionGeral.gravaException("Não foi possível copiar o arquivo " + arquivo, Level.SEVERE, e);
            return 0;
        }
        return 0;
    }

    //Método que remove arquivos do diretório remoto
    public Integer removeArquivoRemoto(String arquivo, String diretorio) {
        if (this.ssh == null) {
            throw new IllegalStateException();
        }
        try {
            if (diretorio.equalsIgnoreCase("Envio")) {
                return ssh.deleteFile(arquivo, diretorioEnvio);
                //statusArquivoRemovido = SFTP.deleteFile(arquivo, DiretorioEnvio, Host, User, Password);
            } else {
                return ssh.deleteFile(arquivo, diretorioRecebimento);
                //statusArquivoRemovido = SFTP.deleteFile(arquivo, DiretorioRecebimento, Host, User, Password);
            }
        } catch (FileTransferException e) {
            ExceptionGeral.gravaException("Não foi possível remover o arquivo "
                    + arquivo, Level.SEVERE, e);
            return 0;
        }
    }

    public void getCloseCache() {
        if (this.ssh == null) {
            throw new IllegalStateException();
        }
        try {
            ssh.closeCache();
        } catch (FileTransferException e) {

        }
    }
}
