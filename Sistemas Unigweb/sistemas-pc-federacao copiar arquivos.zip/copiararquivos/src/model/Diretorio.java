package model;

/**
 *
 * @author DTI - Unimed MS
 */
public enum Diretorio {
    ENVIO("Envio"),
    RECEBIMENTO("Recebimento");
    
    private String descricao;

    public String getDescricao() {
        return descricao;
    }
    
    private Diretorio(String descricao){
        this.descricao = descricao;
    }    
}
