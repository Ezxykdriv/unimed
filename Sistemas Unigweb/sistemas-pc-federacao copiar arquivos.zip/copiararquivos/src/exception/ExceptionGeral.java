package exception;

import java.util.logging.Level;
import util.Email;
import util.GeradorLog;

/**
 *
 * @author DTI - Unimed MS
 */
public class ExceptionGeral {

    public static void gravaException(String mensagem, Level level, Exception exception) {
        GeradorLog gerador = GeradorLog.getInstance();
        gerador.setLevel(level);

        if (exception != null) {
            gerador.log(level, mensagem + "\n" + exception.getMessage());
            /*if (Level.SEVERE == level) {
                Email.email("Erro na rotina de copiar arquivos", mensagem + "\n\n" + exception);
            }*/
        } else {
            gerador.log(level, mensagem);
            /*if (Level.SEVERE == level) {
                Email.email("Erro na rotina de copiar arquivos", mensagem);
            }*/
        }

    }
}
